#include"choice.h"
vector<vector<int>> Choice::Choice_active_choice(0, vector<int>(0, 0));
int Choice::all_choices = 26;